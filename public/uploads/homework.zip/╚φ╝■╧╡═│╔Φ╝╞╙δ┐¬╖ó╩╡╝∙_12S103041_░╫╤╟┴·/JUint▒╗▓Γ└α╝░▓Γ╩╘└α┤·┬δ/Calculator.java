/**
 * 
 */

/**
 * @author MTer
 *
 */
public class Calculator {

	/**
	 * @param args
	 */
		
	private static int result;
	
	Calculator(int n){
		result = n;
	}
	
	public double add(int n){
		result = result + n;
		return result;
	}
	
	public double substract(int n){
		result = result -1;
		return result;
	}
	
	public void multiply(int n){
		
	}
	
	public double divide(int n){
		result = result / n;
		return result;
	}
	
	public double square(int n){
		result = n * n;
		return result;
	}
	
	public void squareRoot(int n){
		for(;;);
	}
	
	public void clear(){
		result = 0;
	}
	
	public int getResult(){
		return result;
	}
	public static void main(String[] args) {
		// TODO �Զ����ɵķ������

	}

}
