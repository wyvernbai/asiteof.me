import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class CalculatorTest {
	
	private Calculator myCalculator;
	
	@Before
	public void setUp() throws Exception {
		myCalculator = new Calculator(5);
	}
	
	@After
	public void tearDown() throws Exception {
		
	}

	@Test
	public void testAdd() {
		Assert.assertEquals("return values", 7, myCalculator.add(2), 0.001);
	}

	@Test
	public void testSubstract() {
		Assert.assertEquals("return values", 6, myCalculator.substract(0), 0.001);
	}

	@Test
	public void testDivide() {
		Assert.assertEquals("return values", 2, myCalculator.divide(3), 0.001);
	}

	@Test
	public void testSquare() {
		Assert.assertEquals("return values", 4, myCalculator.square(2), 0.001);
	}

	@Test
	public void testGetResult() {
		Assert.assertEquals("return values", 4, myCalculator.getResult(), 0.001);
	}

}
