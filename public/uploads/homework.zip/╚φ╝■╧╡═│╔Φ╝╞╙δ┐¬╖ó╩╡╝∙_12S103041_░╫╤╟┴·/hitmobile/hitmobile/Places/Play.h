
#import <Foundation/Foundation.h>


@interface Play : NSObject {

}

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSArray *quotations;

@end
