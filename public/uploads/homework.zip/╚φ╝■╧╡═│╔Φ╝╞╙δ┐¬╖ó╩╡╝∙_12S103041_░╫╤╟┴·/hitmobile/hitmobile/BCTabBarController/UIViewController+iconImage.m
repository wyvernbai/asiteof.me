#import "UIViewController+iconImage.h"


@implementation UIViewController (BCTabBarController)

- (NSString *)iconImageName {
	return nil;
}

@end
