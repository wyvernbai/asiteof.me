#import <Foundation/Foundation.h>


@interface UINavigationController (BCTabBarController)

- (NSString *)iconImageName;

@end
