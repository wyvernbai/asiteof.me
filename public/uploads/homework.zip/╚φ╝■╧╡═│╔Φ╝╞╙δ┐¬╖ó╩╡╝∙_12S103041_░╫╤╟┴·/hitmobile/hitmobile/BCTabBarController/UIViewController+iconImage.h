

@interface UIViewController (BCTabBarController)

- (NSString *)iconImageName;

@end
