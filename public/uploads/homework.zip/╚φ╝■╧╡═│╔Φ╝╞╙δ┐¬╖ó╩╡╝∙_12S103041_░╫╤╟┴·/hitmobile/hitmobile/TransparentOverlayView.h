//
//  TransparentOverlayView.h
//  hitmobile
//
//  Created by 鑫容 郭 on 12-2-20.
//  Copyright (c) 2012年 HIT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TransparentOverlayView : UIView

@end
