//
//  UIFontAdditions.h
//  RichTextDemo
//
//  Created by junmin liu on 10-9-29.
//  Copyright 2010 Openlab. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIFont (Additions)

- (CGFloat)LineHeight;

@end