//
//  UIFontAdditions.m
//  RichTextDemo
//
//  Created by junmin liu on 10-9-29.
//  Copyright 2010 Openlab. All rights reserved.
//

#import "UIFontAdditions.h"


/**
 * Additions.
 */
@implementation UIFont (Additions)


///////////////////////////////////////////////////////////////////////////////////////////////////
- (CGFloat)LineHeight {
	return (self.ascender - self.descender) + 1;
}

@end
