//
//  UITextViewAdditions.h
//  ZhiWeibo
//
//  Created by junmin liu on 10-11-8.
//  Copyright 2010 Openlab. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UITextView (Addtions)

- (void) insertString: (NSString *) insertingString;

@end
