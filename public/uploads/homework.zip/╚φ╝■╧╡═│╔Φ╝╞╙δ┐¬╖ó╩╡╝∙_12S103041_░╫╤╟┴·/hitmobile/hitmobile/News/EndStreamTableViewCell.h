//
//  EndStreamTableViewCell.h
//  iHIT
//
//  Created by keywind on 11-9-18.
//  Copyright 2011年 Hit. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface EndStreamTableViewCell : UITableViewCell {
	UIImageView *imageView;
}

@end
