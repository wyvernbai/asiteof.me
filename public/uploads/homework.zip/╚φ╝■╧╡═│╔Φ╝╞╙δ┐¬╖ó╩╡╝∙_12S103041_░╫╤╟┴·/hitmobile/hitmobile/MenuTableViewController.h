//
//  UselessTableViewController.h
//  hitmobile
//
//  Created by 鑫容 郭 on 12-2-18.
//  Copyright (c) 2012年 HIT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuTableViewController : UITableViewController {
    NSArray *_menuItems;
}

@end
