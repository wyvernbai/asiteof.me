//
//  HITPlace.m
//  ]
//
//  Created by 鑫容 郭 on 12-1-19.
//  Copyright (c) 2012年 HIT. All rights reserved.
//

#import "HITPlace.h"

@implementation HITPlace

@synthesize coordinateX = _coordinateX;
@synthesize coordinateY = _coordinateY;
@synthesize name = _name;
@synthesize detail = _detail;
@synthesize displayLevel = _displayLevel;
@synthesize type = _type;


@end
