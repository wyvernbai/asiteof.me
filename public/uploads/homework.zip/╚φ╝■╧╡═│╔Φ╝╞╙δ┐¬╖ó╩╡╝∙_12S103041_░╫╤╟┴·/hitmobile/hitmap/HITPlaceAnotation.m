//
//  HITPlaceAnotation.m
//  hitmobile
//
//  Created by 鑫容 郭 on 12-2-8.
//  Copyright (c) 2012年 HIT. All rights reserved.
//

#import "HITPlaceAnotation.h"

@implementation HITPlaceAnotation

@synthesize coordinate = _coordinate;

@synthesize title = _title;
@synthesize subtitle = _subtitle;

@synthesize displayLevel = _displayLevel;
@synthesize type = _type;


@end
