//
//  HITPlaceAnnotationView.h
//  hitmobile
//
//  Created by 鑫容 郭 on 12-2-13.
//  Copyright (c) 2012年 HIT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSAnnotationView.h"

@interface HITPlaceAnnotationView : GSAnnotationView

@end
