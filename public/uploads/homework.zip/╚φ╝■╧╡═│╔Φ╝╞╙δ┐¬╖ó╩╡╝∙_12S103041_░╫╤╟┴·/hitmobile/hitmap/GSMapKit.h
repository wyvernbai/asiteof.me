//
//  GSMapKit.h
//  hitmobile
//
//  Created by 鑫容 郭 on 12-2-3.
//  Copyright (c) 2012年 HIT. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef CGPoint GSMapPoint;

@interface GSMapKit : NSObject

@end
