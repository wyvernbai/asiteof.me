//
//  GSUserLocation.m
//  hitmobile
//
//  Created by 鑫容 郭 on 12-2-3.
//  Copyright (c) 2012年 HIT. All rights reserved.
//

#import "GSUserLocation.h"

@implementation GSUserLocation

@synthesize coordinate = _coordinate;
@synthesize radius = _radius;
@synthesize location = _location;
@synthesize updating = _updating;
@synthesize title;
@synthesize subtitle;



@end
