//
//  AppDelegate.h
//  hitweibo
//
//  Created by 鑫容 郭 on 12-3-22.
//  Copyright (c) 2012年 FoOTOo. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WeiboViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) WeiboViewController *viewController;

@end
