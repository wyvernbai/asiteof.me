Action()
{

	web_url("xl7bho.ini",
		"URL=http://media.info.client.xunlei.com/xl7bho.ini",
		"Resource=1",
		"Referer=",
		LAST);

	web_url("WebTours",
		"URL=http://localhost:1080/WebTours",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=",
		"Snapshot=t1.inf",
		"Mode=HTML",
		LAST);

	lr_think_time(10);

	web_submit_form("login.pl",
		"Snapshot=t2.inf",
		ITEMDATA,
		"Name=username", "Value=jojo", ENDITEM,
		"Name=password", "Value=bean", ENDITEM,
		"Name=login.x", "Value=67", ENDITEM,
		"Name=login.y", "Value=5", ENDITEM,
		LAST);

	lr_start_transaction("NewTransaction");

	web_image("Search Flights Button",
		"Alt=Search Flights Button",
		"Snapshot=t3.inf",
		LAST);

	lr_think_time(15);

	web_reg_find("Text=Find Flight",
		LAST);
	web_submit_form("reservations.pl",
		"Snapshot=t4.inf",
		ITEMDATA,
		"Name=depart", "Value=Denver", ENDITEM,
		"Name=departDate", "Value=06/12/2013", ENDITEM,
		"Name=arrive", "Value=Los Angeles", ENDITEM,
		"Name=returnDate", "Value=06/13/2013", ENDITEM,
		"Name=numPassengers", "Value=1", ENDITEM,
		"Name=roundtrip", "Value=<OFF>", ENDITEM,
		"Name=seatPref", "Value={seat}", ENDITEM,
		"Name=seatType", "Value=Coach", ENDITEM,
		"Name=findFlights.x", "Value=49", ENDITEM,
		"Name=findFlights.y", "Value=10", ENDITEM,
		LAST);

	lr_think_time(6);

	web_submit_form("reservations.pl_2",
		"Snapshot=t5.inf",
		ITEMDATA,
		"Name=outboundFlight", "Value=030;251;06/12/2013", ENDITEM,
		"Name=reserveFlights.x", "Value=40", ENDITEM,
		"Name=reserveFlights.y", "Value=9", ENDITEM,
		LAST);

	lr_end_transaction("NewTransaction", LR_AUTO);

	lr_think_time(54);

	web_submit_form("reservations.pl_3",
		"Snapshot=t6.inf",
		ITEMDATA,
		"Name=firstName", "Value=Joseph", ENDITEM,
		"Name=lastName", "Value=Marshall", ENDITEM,
		"Name=address1", "Value=234 Willow Drive", ENDITEM,
		"Name=address2", "Value=San Jose/CA/94085", ENDITEM,
		"Name=pass1", "Value=Joseph Marshall", ENDITEM,
		"Name=creditCard", "Value=12345678", ENDITEM,
		"Name=expDate", "Value=06/10", ENDITEM,
		"Name=saveCC", "Value=<OFF>", ENDITEM,
		"Name=buyFlights.x", "Value=67", ENDITEM,
		"Name=buyFlights.y", "Value=2", ENDITEM,
		LAST);

	web_image("Itinerary Button",
		"Alt=Itinerary Button",
		"Snapshot=t7.inf",
		LAST);

	lr_think_time(32);

	web_image("SignOff Button",
		"Alt=SignOff Button",
		"Snapshot=t8.inf",
		LAST);
	lr_output_message("The flight was booked");

return 0;
}
